"""
Digital Communications Simulation Module

Mark Wickert October 2014

Development continues!
"""

"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import numpy as np
from scipy import signal
import digitalcom as dc
from sys import exit

def psk(m, Nbit, Ns, theta):
    """
    x,data = ask(, Nbit, Ns, theta)
    
    Complex baseband binary psk modulator
    ///////////////////////////////////////////////////////////////
    m = modulation index; m = 0 ==> BPSK
    Nbit = number of symbols processed
    Ns = the number of samples per bit
    theta = Rotate the complex baseband signal by theta radians
    x = Complex baseband transmit signal vector {-1,+1}
    data = Binary {0,1} data being sent; used for error detecting
    ///////////////////////////////////////////////////////////////
    Mark Wickert October 2014
    """
    A = 1
    y,b,data = dc.NRZ_bits(Nbit, Ns) # Rect pulse shape by default
    x = A*(np.sqrt(1 - m**2)*y+1j*m)*np.exp(1j*theta)
    return x, b, data

def psk_sim(SNR,m,theta,Nbits,timing):
    """
    Pe,Bit_errors,Bit_count,z = ask_sim(SNR,theta,Nbits,timing)
    
    Coherent ASK modem end-to-end simulation function
    /////////////////////////////////////////////////////////////////
           SNR = Set the received signal SNR in dB; for on-off keying 
                 the SNR is defined interms of the average signal 
                 power, e.g., 1/2 the peak symbol energy
             m = modulation index, m= 0 ==> BPSK
         theta = Rotate the complex baseband signal by theta radians
         Nbits = The number of bits simulated
        timing = Sets the sampler timing to give the minimum BEP; 
                 find value using eyeplot_mark function
            Pe = Estimated bit error probability (BEP)
    Bit_errors = Number of bit errors found (good to obtain at least 
                 100 errors over an AWGN channel
     Bit_count = The number of bits processed y bit_errors function; 
                 If you create a 'top-level' function 'errors' and 
                 'RecBits' can be used to combine results from multiple
                  runs
             z = Receiver decision statistic; use as input to eyeplot 
                 for further analysis, e.g., find a good value 
                 for 'timing'
    ////////////////////////////////////////////////////////////////
    Mark Wickert October 2014
    """
    Ns = 16 # Fix the number of samples per bit to 16

    # Generate PSK tx signal
    x,b,data = psk(m, Nbits, 16, theta)
    y = dc.cpx_AWGN(x,SNR,16) # AWGN channel

    # Enter receiver
    # Coherent receiver (at complex baseband)
    #////////////////////////////////
    # Matched filter is a rectangle pulse
    b_REC = b/np.sum(b) # make filter unity gain at dc
    # Process complex BB signal through filter to form decision statistic
    z = signal.lfilter(b_REC,1,y)
    z_det = z.real
    # Decision logic
    d_hat = (np.sign(z_det[timing::16])+1)/2 # {0,1} logic levels
    # Error detect
    Bit_count, Bit_errors = dc.bit_errors(data,d_hat)
    Pe = Bit_errors/float(Bit_count)
    return Pe,Bit_errors,Bit_count,z