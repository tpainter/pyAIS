from __future__ import division
"""
OFDM Function Module

Mark Wickert November 2014 - December 2014

Development continues!
"""

"""
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

#from matplotlib import pylab
#from matplotlib import mlab
import numpy as np
from numpy import fft
import matplotlib.pyplot as plt
from scipy import signal
import digitalcom as dc
#from scipy.special import erfc
#from sys import exit

def OFDM_tx(IQ_data,Nf,N,Np=0,cp=False,Ncp=0):
    """
    x_out = OFDM_tx(IQ_data,Nf,N,Np=0,cp=False,Ncp=0)
    ============================================================================
    IQ_data = +/-1, +/-3, etc complex QAM symbol sample inputs
         Nf = number of filled carriers, must be even and Nf < N
          N = total number of carriers; generally a power 2, e.g., 64, 1024, etc
         Np = Period of pilot code blocks; 0 <=> no pilots
         cp = False/True <=> bypass cp insertion entirely if False
        Ncp = the length of the cyclic prefix
    ============================================================================
     x_out = complex baseband OFDM waveform output after P/S and CP insertion
    ============================================================================
    
    Mark Wickert November-December 2014
    """
    N_symb = len(IQ_data)
    N_OFDM = N_symb//Nf
    IQ_data = IQ_data[:N_OFDM*Nf]
    IQ_s2p = np.reshape(IQ_data,(N_OFDM,Nf)) #carrier symbols by column
    print(IQ_s2p.shape)
    if Np > 0:
        IQ_s2p = mux_pilot_blocks(IQ_s2p,Np)
        N_OFDM = IQ_s2p.shape[0]
        print(IQ_s2p.shape)
    if cp:
        x_out = np.zeros(N_OFDM*(N+Ncp),dtype=np.complex128) 
    else:
        x_out = np.zeros(N_OFDM*N,dtype=np.complex128)
    for k in xrange(N_OFDM):
        buff = np.zeros(N,dtype=np.complex128)
        for n in range(-Nf//2,Nf//2+1):
            if n == 0:  # Modulate carrier f = 0
                buff[0] = 0 # This can be a pilot carrier
            elif n > 0: # Modulate carriers f = 1:Nf/2
                buff[n] = IQ_s2p[k,n-1]
            else:       # Modulate carriers f = -Nf/2:-1
                buff[N+n] = IQ_s2p[k,Nf+n]
        if cp:
            #With cyclic prefix
            x_out_buff = fft.ifft(buff)
            x_out[k*(N+Ncp):(k+1)*(N+Ncp)] = np.concatenate((x_out_buff[N-Ncp:],\
                                                          x_out_buff))
        else:
            # No cyclic prefix included
            x_out[k*N:(k+1)*N] = fft.ifft(buff) 
    return x_out

def mux_pilot_blocks(IQ_data,Np):
    """
    IQ_datap = mux_pilot_blocks(IQ_data,Np)
    
    A helper function called by OFDM_tx that inserts pilot block for use
    in channel estimation when a delay spread channel is present.
    =========================================================================
     IQ_data = a 2D array of input QAM symbols with the columns 
               representing the NF carrier frequencies and each 
               row the QAM symbols used to form an OFDM symbol
          Np = the period of the pilot blocks; e.g., a pilot block is
               inserted every Np OFDM symbols (Np-1 OFDM data symbols 
               of width Nf are inserted in between the pilot blocks.
    =========================================================================          
    IQ_datap = IQ_data with pilot blocks intserted
    =========================================================================
    
    Mark Wickert December 2014
    """
    N_OFDM = IQ_data.shape[0]
    Npb = N_OFDM//(Np-1)
    N_OFDM_rem = N_OFDM - Npb*(Np-1)
    Nf = IQ_data.shape[1]
    IQ_datap = np.zeros((N_OFDM + Npb + 1,Nf),dtype=np.complex128)
    pilots = np.ones(Nf) # The pilot symbol is simply 1 + j0
    for k in xrange(Npb):
        IQ_datap[Np*k:Np*(k+1),:] = np.vstack((pilots,\
                                    IQ_data[(Np-1)*k:(Np-1)*(k+1),:]))
    IQ_datap[Np*Npb:Np*(Npb+N_OFDM_rem),:] = np.vstack((pilots,\
                                    IQ_data[(Np-1)*Npb:,:]))
    return IQ_datap

def OFDM_rx(x,Nf,N,Np=0,cp=False,Ncp=0,alpha=0.95,ht=None):
    """
    z_out, H = OFDM_rx(x,Nf,N,Np=0,cp=False,Ncp=0,alpha = 0.95,ht=None)
    ============================================================================
          x = received complex baseband OFDM signal
         Nf = number of filled carriers, must be even and Nf < N
          N = total number of carriers; generally a power 2, e.g., 64, 1024, etc
         Np = Period of pilot code blocks; 0 <=> no pilots; -1 <=> use the ht
              impulse response input to equalize the OFDM symbols; note
              equalization still requires Ncp > 0 to work on a delay spread
              channel.
         cp = False/True <=> if False assume no CP is present
        Ncp = the length of the cyclic prefix
      alpha = the filter forgetting factor in the channel estimator
              Typically alpha is 0.9 to 0.99.
         nt = input the known theortical channel impulse response
    ============================================================================
     z_out = recovered complex baseband QAM symbols as a serial stream;
             as appropriate channel estimation has been applied.
         H = channel estimate (in the frequency domain at each subcarrier)
    ============================================================================    
    
    Mark Wickert November 2014
    """
    N_symb = len(x)//(N+Ncp)
    y_out = np.zeros(N_symb*N,dtype=np.complex128)
    for k in xrange(N_symb):
        if cp:
            # Remove the cyclic prefix
            buff = x[k*(N+Ncp)+Ncp:(k+1)*(N+Ncp)]
        else:
            buff = x[k*N:(k+1)*N]
        y_out[k*N:(k+1)*N] = fft.fft(buff)
    # Demultiplex into Nf parallel streams from N total, including
    # the pilot blocks which contain channel information
    z_out = np.reshape(y_out,(N_symb,N))
    z_out = np.hstack((z_out[:,1:Nf//2+1],z_out[:,N-Nf//2:N]))
    if Np > 0:
        if ht == None:
            z_out,H = chan_est_equalize(z_out,Np,alpha)
        else:
            Ht = fft.fft(ht,N)
            Hht = np.hstack((Ht[1:Nf//2+1],Ht[N-Nf//2:]))
            z_out,H = chan_est_equalize(z_out,Np,alpha,Hht)
    elif Np == -1: # Ideal equalization using hc
        Ht = fft.fft(ht,N)
        H = np.hstack((Ht[1:Nf//2+1],Ht[N-Nf//2:]))
        for k in xrange(N_symb):
            z_out[k,:] /= H
    else:
        H = np.ones(Nf)
    # Multiplex into original serial symbol stream
    return z_out.flatten(),H

def chan_est_equalize(z,Np,alpha,Ht=None):
    """
    zz_out,H = chan_est_eq(z,Nf,Np,alpha,Ht=None)
    
    This is a helper function for OFDM_rx to unpack pilot blocks from
    from the entire set of received OFDM symbols (the Nf of N filled
    carriers only); then estimate the channel array H recursively,
    and finally apply H_hat to Y, i.e., X_hat = Y/H_hat 
    carrier-by-carrier. Note if Np = -1, then H_hat = H, the true
    channel.
    =================================================================
        z = Input N_OFDM x Nf 2D array containing pilot blocks and
            OFDM data symbols.
       Np = the pilot block period; if -1 use the known channel 
            impuls response input to ht.
    alpha = The forgetting factor used to recursively estimate H_hat
       Ht = the theoretical channel frquency response to allow ideal
            equalization provided Ncp is adequate.
    =================================================================
    zz_out= The input z with the pilot blocks removed and one-tap
            equalization applied to each of the Nf carriers.
        H = The channel estimate in the frequency domain; an array
            of length Nf; will return Ht if provided as an input.
    =================================================================
    
    Mark Wickert December 2014
    """
    N_OFDM = z.shape[0]
    Nf = z.shape[1]
    #Npb = N_OFDM//Np
    #N_part = N_OFDM - Npb*Np - 1
    zz_out = np.zeros_like(z)
    Hmatrix = np.zeros((N_OFDM,Nf),dtype=np.complex128)
    k_fill = 0
    k_pilot = 0
    for k in xrange(N_OFDM):
        if np.mod(k,Np) == 0: # Process pilot blocks
            if k == 0:
                H = z[k,:]
            else:
                H = alpha*H + (1-alpha)*z[k,:]
            Hmatrix[k_pilot,:] = H
            k_pilot += 1
        else:              # process data blocks
            if Ht == None:
                zz_out[k_fill,:] = z[k,:]/H # apply equalizer
            else:
                zz_out[k_fill,:] = z[k,:]/Ht # apply ideal equalizer
            k_fill += 1
    zz_out = zz_out[:k_fill,:] # Trim to # of OFDM data symbols
    Hmatrix = Hmatrix[:k_pilot,:] # Trim to # of OFDM pilot symbols
    if k_pilot > 0: #Plot a few magnitude and phase channel estimates
        chan_idx = np.arange(0,Nf//2,4)
        plt.subplot(211)
        for i in chan_idx:
            plt.plot(abs(Hmatrix[:,i]))
            plt.title('Channel Estimates H[k] Over Selected Carrier Indices')
            plt.ylabel('|H[k]|')
        plt.grid();
        plt.subplot(212)
        for i in chan_idx:
            plt.plot(np.angle(Hmatrix[:,i]))
            plt.xlabel('Channel Estimate Update Index')
            plt.ylabel('angle[H[k] (rad)')
        plt.grid();
        plt.show()
    return zz_out,H

if __name__ == '__main__':
    # one sample per symbol 16QAM
    x,b,IQ_data = dc.QAM_bb(10000,1,'64qam')
    # OFDM transmitter
    x_out = OFDM_tx(IQ_data,Nf=32,N=64,Np=10,cp=True,Ncp=5)
    # delay spread channel
    hc = np.array([1.0, 0.1, -0.05, 0.15, 0.2, 0.05])
    c_out = signal.lfilter(hc,1,x_out)
    # AWGN channel
    r_out = dc.cpx_AWGN(c_out,40,64/32)
    # OFDM receiver
    z_out,H = OFDM_rx(r_out,Nf=32,N=64,Np=10,cp=True,Ncp=5,alpha=0.95,ht=hc)
    Nsymb,Nerrs,SEP_hat = dc.QAM_SEP(z_out,x,'64qam')

    